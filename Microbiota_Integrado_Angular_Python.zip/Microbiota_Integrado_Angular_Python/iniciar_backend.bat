@echo off
cd /d "%~dp0Libreria_Python"
python api_server.py
pause
