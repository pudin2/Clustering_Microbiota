@echo off
cd /d "%~dp0microbiota-health-angular"
npm start
pause
