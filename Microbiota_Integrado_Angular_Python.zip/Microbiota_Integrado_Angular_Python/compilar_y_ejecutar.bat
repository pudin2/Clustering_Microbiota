@echo off
setlocal
cd /d "%~dp0microbiota-health-angular"
if not exist node_modules (
  echo Instalando dependencias Angular...
  call npm install
  if errorlevel 1 goto :error
)
echo Compilando Angular...
call npm run build
if errorlevel 1 goto :error
cd /d "%~dp0Libreria_Python"
echo Iniciando aplicacion integrada en http://127.0.0.1:8765
python api_server.py
goto :eof
:error
echo Ocurrio un error. Revisa los mensajes anteriores.
pause
