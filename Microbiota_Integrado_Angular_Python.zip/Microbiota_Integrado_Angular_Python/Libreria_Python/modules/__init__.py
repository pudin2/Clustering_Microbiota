"""Paquetes funcionales del proyecto."""
